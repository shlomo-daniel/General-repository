import { onStart } from "./helpers/dom.js";

onStart();
